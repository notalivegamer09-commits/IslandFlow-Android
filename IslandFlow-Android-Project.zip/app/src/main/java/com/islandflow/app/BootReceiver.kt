package com.islandflow.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (intent?.action == Intent.ACTION_BOOT_COMPLETED && Settings.canDrawOverlays(context)) {
            context.startService(Intent(context, IslandOverlayService::class.java))
        }
    }
}
