package com.islandflow.app

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(28), dp(24), dp(28))
            setBackgroundColor(0xFF0B0B12.toInt())
        }
        val title = TextView(this).apply {
            text = "IslandFlow 2.0"
            textSize = 30f
            setTextColor(0xFFFFFFFF.toInt())
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Your Android Dynamic Island"
            textSize = 15f
            setTextColor(0xFFB7A5F8.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(28))
        }
        val overlay = Button(this).apply {
            text = "1. Allow display over other apps"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                } else startIsland()
            }
        }
        val notifications = Button(this).apply {
            text = "2. Enable notification access"
            setOnClickListener { startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")) }
        }
        val start = Button(this).apply {
            text = "3. Start Dynamic Island"
            setOnClickListener { startIsland() }
        }
        val info = TextView(this).apply {
            text = "Allow the two permissions above, then start the island. Notification access lets IslandFlow show app alerts. You control these permissions in Android Settings."
            textSize = 13f
            setTextColor(0xFFAAA6B7.toInt())
            gravity = Gravity.CENTER
            setPadding(0, dp(22), 0, 0)
        }
        layout.addView(title)
        layout.addView(subtitle)
        layout.addView(overlay, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) })
        layout.addView(notifications, LinearLayout.LayoutParams(-1, dp(54)).apply { bottomMargin = dp(10) })
        layout.addView(start, LinearLayout.LayoutParams(-1, dp(54)))
        layout.addView(info)
        setContentView(layout)
    }
    private fun startIsland() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        startService(Intent(this, IslandOverlayService::class.java))
        finish()
    }
}
