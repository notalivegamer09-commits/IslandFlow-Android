package com.islandflow.app

import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.BatteryManager
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class IslandOverlayService : Service() {
    private lateinit var windowManager: WindowManager
    private var island: LinearLayout? = null
    private var expanded = false
    private var statusText: TextView? = null
    private var detailText: TextView? = null
    private var batteryReceiver: BroadcastReceiver? = null
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        showIsland()
        registerBattery()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val title = intent?.getStringExtra("title")
        val text = intent?.getStringExtra("text")
        if (!title.isNullOrBlank()) {
            if (island == null) showIsland()
            showNotification(title, text ?: "New notification")
        }
        return START_STICKY
    }

    private fun showIsland() {
        if (island != null) return
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(9), dp(18), dp(9))
            background = GradientDrawable().apply {
                setColor(0xFF030304.toInt())
                cornerRadius = dp(28).toFloat()
                setStroke(dp(1), 0xFF282630.toInt())
            }
            elevation = dp(12).toFloat()
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val dot = View(this).apply {
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(0xFF9B78FF.toInt())
            }
        }
        top.addView(dot, LinearLayout.LayoutParams(dp(9), dp(9)))
        statusText = TextView(this).apply {
            text = "IslandFlow"
            textSize = 12f
            setTypeface(null, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(dp(10), 0, 0, 0)
        }
        top.addView(statusText, LinearLayout.LayoutParams(0, -2, 1f))
        val pulse = TextView(this).apply {
            text = "● ● ●"
            textSize = 7f
            setTextColor(0xFF9B78FF.toInt())
        }
        top.addView(pulse)
        container.addView(top, LinearLayout.LayoutParams(-1, dp(24)))
        detailText = TextView(this).apply {
            text = "Tap to expand your island"
            textSize = 10f
            setTextColor(0xFFAAA6B7.toInt())
            visibility = View.GONE
            setPadding(dp(19), dp(8), 0, dp(2))
        }
        container.addView(detailText)
        container.setOnClickListener {
            expanded = !expanded
            detailText?.visibility = if (expanded) View.VISIBLE else View.GONE
            detailText?.text = if (expanded) "Dynamic Island is active  ·  Tap to collapse" else "Tap to expand your island"
            val params = container.layoutParams as WindowManager.LayoutParams
            params.width = if (expanded) dp(280) else dp(180)
            params.height = WindowManager.LayoutParams.WRAP_CONTENT
            windowManager.updateViewLayout(container, params)
        }
        val params = WindowManager.LayoutParams(
            dp(180), WindowManager.LayoutParams.WRAP_CONTENT,
            if (android.os.Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = dp(10)
        }
        island = container
        windowManager.addView(container, params)
    }

    private fun registerBattery() {
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val plugged = intent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) ?: 0
                if (level >= 0 && plugged != 0) {
                    statusText?.text = "⚡ Charging · $level%"
                    detailText?.text = "Power connected · Battery $level%"
                    detailText?.visibility = View.VISIBLE
                    expanded = true
                }
            }
        }
        batteryReceiver = receiver
        registerReceiver(receiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
    }

    fun showNotification(title: String, text: String) {
        statusText?.text = title.take(26)
        detailText?.text = text.take(80)
        detailText?.visibility = View.VISIBLE
        expanded = true
    }

    override fun onDestroy() {
        batteryReceiver?.let { try { unregisterReceiver(it) } catch (_: Exception) {} }
        island?.let { try { windowManager.removeView(it) } catch (_: Exception) {} }
        island = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
