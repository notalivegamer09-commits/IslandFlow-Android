package com.islandflow.app

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class IslandNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val notification = sbn?.notification ?: return
        val extras = notification.extras
        val title = extras.getCharSequence("android.title")?.toString() ?: sbn.packageName
        val text = extras.getCharSequence("android.text")?.toString() ?: "New notification"
        try {
            startService(android.content.Intent(this, IslandOverlayService::class.java).apply {
                putExtra("title", title)
                putExtra("text", text)
            })
        } catch (_: Exception) { }
    }
}
