# IslandFlow 2.0 — Native Android starter

This is the first native Android foundation for the IslandFlow Dynamic Island prototype.

## Build an APK with GitHub Actions
1. Create a new GitHub repository.
2. Upload the contents of this folder (not the ZIP file itself).
3. Open the repository's **Actions** tab.
4. Select **Build IslandFlow APK** and press **Run workflow** (or wait for the first push build).
5. Open the completed workflow run and download the `IslandFlow-debug-apk` artifact.
6. Extract the artifact ZIP and install `app-debug.apk` on your Android phone.

## First launch
1. Open IslandFlow.
2. Allow **Display over other apps**.
3. Enable **Notification access** for IslandFlow in Android Settings.
4. Return to the app and tap **Start Dynamic Island**.

## Current prototype scope
- Native Android overlay window.
- Tap-to-expand/collapse island.
- Basic battery charging status.
- Notification-listener foundation.
- GitHub Actions APK build workflow.

This is an early native foundation, not a finished feature-equivalent release. Notification forwarding, media-session controls, call-state integration, persistent background behavior and OEM-specific testing still need further implementation. Android and Realme battery/background restrictions may affect overlay persistence.
